var sqlite3 = require('sqlite3').verbose()


// set path db
const DBSOURCE = "./db.sql"


let db = new sqlite3.Database(DBSOURCE, (err) => {
    if (err) {
      // Cannot open database
      console.error(err.message)
      throw err
    }else{
        console.log('Connected to the SQLite database.')

    }
});

// per import in altri file
module.exports = db