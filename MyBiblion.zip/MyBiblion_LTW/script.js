// gestisce eventi grafico ovvero refresh e selezione tramite mouseover su elementi
function handleGraph(toG, event) {
  var getMinMax = (a, b) => {
    return a <= b ? [a, b] : [b, a];
  };
  var x = event.offsetX;
  var y = event.offsetY;
  var xmin,
    xmax = 0;
  var ymin,
    ymax = 0;
  var selected = false;
  toG.rects.forEach((element) => {
    [xmin, xmax] = getMinMax(element.x_start, element.x_start + element.width);
    [ymin, ymax] = getMinMax(element.y_start, element.y_start + element.height);
    if (x >= xmin && x <= xmax && y >= ymin && y <= ymax) {
      toG.ctx.fillStyle = "white";
      toG.ctx.fillRect(
        element.x_start,
        element.y_start,
        element.width,
        element.height
      );
      toG.ctx.fillStyle = "black";
      toG.ctx.fillText(
        element.val,
        -10 + xmin + (xmax - xmin) / 2,
        ymin - element.th
      );
      toG.ctx.globalAlpha = 0.5;
      toG.ctx.fillStyle = "red";
      toG.ctx.fillRect(
        element.x_start,
        element.y_start,
        element.width,
        element.height
      );
      selected = element;
      return;
    }
  });

  toG.rects.forEach((e) => {
    [xmin, xmax] = getMinMax(e.x_start, e.x_start + e.width);
    [ymin, ymax] = getMinMax(e.y_start, e.y_start + e.height);
    if (selected != e) {
      toG.ctx.fillStyle = "white";
      toG.ctx.fillRect(e.x_start, e.y_start, e.width, e.height - e.th);
      toG.ctx.clearRect(xmin, ymin, e.width, e.height);
      toG.ctx.globalAlpha = 1;
      toG.ctx.fillStyle = "blue";
      toG.ctx.fillRect(e.x_start, e.y_start, e.width, e.height);
      return;
    }
  });
}
// manipola index.html per mostrare pagina write
function getWritePage(homeStyle, baseUrl, reqBodyx, write_s, userObj) {
  var $homepg = null;
  $("#view").load(baseUrl + "write", function (response, status) {
    $("#profile-usn").mouseenter(() => {
      $("#profile-usn").css("cursor", "pointer");
    });
    $("#profile-usn").click(async () => {
      await getHome($homepg, baseUrl, reqBodyx, write_s, userObj, true);
    });
    $("textarea[name='descr']").css("font-weight", "initial");
    let header = document.querySelector("header");
    window.addEventListener("scroll", () => {
      header.classList.toggle("shadow", window.scrollY > 0);
    });
    $("#resetWrite").click(() => {
      $(
        "input[name='title'],input[name='tag'],textarea[name='descr'],input[name='foto']"
      ).val("");
    });
    //aggiungi articolo 
    $(".post-box").submit(async function (event) {
      event.preventDefault();
      var articleData = {
        title: $("input[name='title']").val(),
        content: $("textarea[name='descr']").val(),
        theme: $("input[name='tag']").val(),
        author: userObj.username,
        image: $("input[name='image']").val(),
      };

      var file = $("input[name='foto']")[0].files[0];

      await getBase64(file).then((data) => {
        articleData.image = data;
      });
      // richiesta per inserire articolo
      $.ajax({
        type: "POST",
        url: baseUrl + "articles/",
        data: JSON.stringify(articleData),
        success: (data, status, jq) => {
          $(".post-filter").remove();
          $("section.post").html(`
                    <div role="alert">
                      The article has been inserted successfully
                    </div>`);
          $("section.post").css("position", "relative");
          $("section.post").css("color", "rgb(10, 54, 34)");
          $("section.post").css("background-color", "rgb(209, 231, 221)");
          $("section.post").css("margin-top", "1rem");
          $("section.post").css("border-radius", "3px");
        },
        dataType: "json",
        contentType: "application/json",
      });
    });

    $("#logo-home").mouseenter(() => {
      $("#logo-home").css("cursor", "pointer");
    });

    clearPg();
    $homepg = $(".shpg").detach();
    $("head").append(write_s);
    //click logo mybiblion torna a homepage
    $("#logo-home").click(async () => {
      $(".logcss").remove();
      $("head").append($homepg);
      reqBodyx.isProfileSearch = false;
      await getHome(homeStyle, baseUrl, reqBodyx, write_s, userObj, false);
      clearPg();
    });

    $("#profile-usn").text(userObj.username);
    $(".logcss").remove();
    $("head").append(write_s);
  });
  let header = document.querySelector("header");

  window.addEventListener("scroll", () => {
    header.classList.toggle("shadow", window.scrollY > 0);
  });
}

//disegna grafico stats
function getChart(data_y, data_x) {
  var ctx = $("canvas").get(0).getContext("2d");
  var canvas = $("canvas").get(0);
  canvas.width = canvas.getBoundingClientRect().width;
  canvas.height = canvas.getBoundingClientRect().height;
  const max = data_y.reduce((a, b) => Math.max(a, b), -Infinity);
  var dwidth = window.innerWidth > 0 ? window.innerWidth : screen.width;
  if (dwidth < 600) {
    $("canvas").css("width", "100%");
  }
  ctx.font = "1em serif";
  //scrivi etichette y ax
  var yaxOff = 0;
  var toEv = max%2
  if (max >= 4) {
    for (var i = 0; i <= (max+toEv)/2; i++) {
      yaxOff = Math.max(
        ctx.measureText(`${Math.ceil((max+toEv) * (1-(i/((max+toEv)/2))))}`).width,
        yaxOff
      );
      ctx.fillText(
        `${Math.ceil((max+toEv) * (1-(i/((max+toEv)/2))))}`,
        10,
        58 + (20 * i * canvas.height) / 200
      );
    }
  } else {
    for (var i = 0; i < max + 1; i++) {
      yaxOff = Math.max(
        ctx.measureText(`${max - i}`).width,
        yaxOff
      );
      ctx.fillText(
        `${max ? Math.ceil(max - i) : 0}`,
        10,
        58 + (20 * i * canvas.height) / 200
      );
    }
  }

  yaxOff += 10;
  // disegna y ax
  ctx.moveTo(yaxOff + 10, 40);
  ctx.lineTo(yaxOff + 10, 40 + (30 * i * canvas.height) / 200);
  ctx.stroke();

  //disegna x axes
  var segX = (200 * canvas.width) / 100;
  ctx.moveTo(0, 60 + (20 * (i - 1) * canvas.height) / 200);
  ctx.lineTo(segX, 60 + (20 * (i - 1) * canvas.height) / 200);
  ctx.stroke();
  var pos_y = 20 + (20 * (i - 1) * canvas.height) / 200;
  var xl = 10 + (20 * (i - 1) * canvas.height) / 200;
  var x_lable_height = 80 + (20 * (i - 1) * canvas.height) / 200;
  var xaxOff = yaxOff + 30;
  var rcts = [];
  toEv = max <4 ? 0 : toEv
  for (var i = 0; i < data_x.length; i++) {
    // scrivi etichette x ax
    ctx.fillStyle = "black";
    ctx.fillText(
      data_x[i],
      xaxOff + 20 * i * (canvas.width / 600),
      x_lable_height
    );
      //disegna rettangoli
    ctx.fillStyle = "blue";
    ctx.fillRect(
      xaxOff + 20 * i * (canvas.width / 600),
      x_lable_height - 20,
      ctx.measureText(`${data_x[i]}`).width,
      data_y[i] > 0
        ? -pos_y * (data_y[i] / (max+toEv))
        : xl * (-data_y[i] / max)
    );
    rcts.push({
      height:
        data_y[i] > 0
          ? -pos_y * (data_y[i] / (max+toEv))
          : xl * (-data_y[i] / max),
      width: ctx.measureText(`${data_x[i]}`).width,
      x_start: xaxOff + 20 * i * (canvas.width / 600),
      y_start: x_lable_height - 20,
      val: data_y[i],
      th:
        data_y[i] > 0
          ? ctx.measureText(`${data_y[0]}`).actualBoundingBoxAscent
          : 0,
    });
    xaxOff += ctx.measureText(`${data_x[i]}`).width;
  }

  return { ctx: ctx, rects: rcts };
}

// funzione util che restituisce array ultimi 7 giorni formato stringa "mm:dd"
function genDatesStats() {
  var dates = [];
  for (var i = 1; i < 8; i++) {
    nd = new Date();
    nd.setDate(new Date().getDate() - 7 + i);
    dates.push(nd.toISOString().substring(6, 10));
  }
  return dates;
}
// restituisce tutto il codice html necessario relativo alla singola card articolo
function createPost(
  postImage,
  author,
  theme,
  title,
  description,
  authorImage,
  aid,
  birth,
  hasHeader
) {
  date = new Date(birth * 1000).toString().slice(0, 16);
  description = description.slice(0, 261);
  var $head = `
  <div class="post-header2">

    <div class="post-stat2">
      <div class="seg-stat"></div>
    </div>
    <div class="post-space2">
    </div>
    <div class="post-del2">
      <div class="seg-2"></div>
      <div class="seg-del"></div>
    </div>

  </div>`;

  return `
  <div id="shape">

    <div class="post-container2" data-aid="${aid}">
        ${hasHeader ? $head : "<div style='flex:.05;'></div>"}
    <div class="imagecon">
        <div class="leftimage" style="flex:.05"></div>
        <div class="post-image2" style='border-radius:4px;background:url(${postImage})'> </div>
        <div class="rightimage" style="flex:.05"></div>
    </div>

    <div class="post-body2">
        <div class="post-theme2">
            <h2 class="category" style="margin-top:5px;margin-left:5px;">${theme}</h2>
        </div>
        <div class="post-title2">
            <a class="post-title" data-aid="${aid}" style="margin-left:5px;text-decoration-line: none; cursor: pointer;">${title} </a>
        </div>
        <div class="post-date2">
            <span class="post-date" style="margin-left:5px;">${date}</span>
        </div>
        <div class="post-content2">
            <p class="post-description" style="margin-left:5px;">${description}</p>
        </div>
        <div class="post-footer2">
            <img src="${authorImage}" alt="" class="profile-img" style="margin-left:5px;">
            <span class="profile-name" style="margin:5px">${author}</span>
        </div>
    </div>
    </div>

  </div>`;
}

function clearPg() {
  $("#view head").remove();
  $("#view meta").remove();
  $("#view title").remove();
  $("#view link").remove();
}

//encoding base64 util per immagini
function getBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });
}
// manipola index.html per mostrare pagina home/profile in base a var getProfile
function getHome(
  homeStyle,
  baseUrl,
  reqBodyx,
  write_s,
  userObj,
  getProfile,
  fromlogin = false
) {
  var $homepg = null;
  reqBodyx.pattern = ".";
  if (homeStyle) {
    $("head").append(homeStyle);
  }
  $(window).off("resize");
  if (getProfile) {
    reqBodyx.isProfileSearch = true;
  } else {
    reqBodyx.isProfileSearch = false;
  }
  if (fromlogin) {
    $("#view").html("");
  }
  clearPg();
  // richiesta al server delle cards
  $.ajax({
    type: "GET",
    url: baseUrl + "articles/",
    dataType: "json",
    data: reqBodyx,
    success: (data, status, jq) => {
      // display pagina home con gestione eventi
      $("#view").load(baseUrl + "home", function (response, status) {
        $(".logo").css("text-decoration-line", "none");
        $("#profile-usn").css("text-decoration-line", "none");
        $("head").append(
          `<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">`
        );

        $("#profile-usn").mouseenter(() => {
          $("#profile-usn").css("cursor", "pointer");
        });
        $(".logo").mouseenter(() => {
          $(".logo").css("cursor", "pointer");
        });
        $(".logo").click(async () => {
          reqBodyx.isProfileSearch = false;
          await getHome($homepg, baseUrl, reqBodyx, write_s, userObj, false);
        });
        $("#profile-usn").click(async () => {
          $(".logcss").remove();
          await getHome($homepg, baseUrl, reqBodyx, write_s, userObj, true);
        });
        if (getProfile) {
          reqBodyx.isProfileSearch = true;
          $("#sp-art").text("My Articles");
        }
        $(".logcss").remove();
        clearPg();
        $("#sp-art").click(async () => {
          await getHome(
            $homepg,
            baseUrl,
            reqBodyx,
            write_s,
            userObj,
            getProfile
          );
        });
        $("#profile-usn").text(userObj.username);
        // crea cards articoli se non esiste immagine autore seleziona img default
        var article = data.articles;
        for (var i = 0; i < article.length; i++) {
          var pImg = article[i].proImg;
          if (!pImg) {
            pImg = "assets/user.png";
          }
          $("section.post").append(
            createPost(
              article[i].image,
              article[i].author,
              article[i].theme,
              article[i].title,
              article[i].content,
              pImg,
              article[i].id,
              article[i].birth,
              getProfile
            )
          );
        }

        $(".seg-del").mouseenter(function () {
          $(this).css("cursor", "pointer");
          $(this).css("background-color", "red");
          $(this).css("border-radius", "4px");
        });
        $(".seg-del").mouseleave(function () {
          $(this).css("cursor", "initial");
          $(this).css("background-color", "white");
        });
        //rimuove articolo
        $(".seg-del").click(function () {
          $.ajax({
            type: "DELETE",
            url:
              baseUrl +
              "articles/" +
              $(this).parent().parent().parent().attr("data-aid"),
            success: async () => {
              $(".logcss").remove();
              await getHome($homepg, baseUrl, reqBodyx, write_s, userObj, true);
            },
          });
        });

        $(".seg-stat").mouseenter(function () {
          $(this).css("cursor", "pointer");
          $(this).css("background-color", "yellow");
        });
        $(".seg-stat").mouseleave(function () {
          $(this).css("cursor", "initial");
          $(this).css("background-color", "white");
        });
        //mostra grafico click di articolo
        $(".seg-stat").click(async function () {
          $("section.container").remove();
          $(
            "<div id='stat' style='display:flex;justify-content: center;height:50vh;'><canvas style='align-self:center;height:100%;'></canvas></div>"
          ).insertAfter(".post-filter");
          $(
            `<div id="sel-stat" style="display:flex; justify-content:center;">
              <label for="chart-sel" style="margin-top:20px">Numero di click negli ultimi 7 giorni</label>
            </div>
            
          `
          ).insertAfter(".post-filter");
          $(".form-inline").hide();
          $("#write-it").hide();

          $('select[name="chart-sel"]').css({
            color: "white",
            "background-color": "var(--second-color)",
            border: "none",
            "border-radius": "2px",
            "margin-left": "5px",
          });
          //estrai da card id dell'articolo
          var ad = $(this).parent().parent().parent().attr("data-aid");
          var dt = [];
          var dates = genDatesStats();
          // chiedi stats ultimi 7 giorni per articolo ad
          for (var d of dates) {
            await $.ajax({
              type: "GET",
              url: baseUrl + `articles/${ad}/clickStats/${d}`,
              dataType: "json",
              success: (data, status, jq) => {
                dt.push(data.count);
              },
            });
          }
          // al resize della pagina ridisegna grafico
          $(window).on("resize", async function () {
            $("#stat").remove();
            $("#sel-stat").remove();
            $(
              "<div id='stat' style='display:flex;justify-content: center;height:50vh;'><canvas style='align-self:center;height:100%;'></canvas></div>"
            ).insertAfter(".post-filter");
            $(
              `<div id="sel-stat" style="display:flex; justify-content:center;">
                <label for="chart-sel" style="margin-top:20px">Numero di click negli ultimi 7 giorni</label>
              </div> `
            ).insertAfter(".post-filter");
            $(".form-inline").hide();
            $("#write-it").hide();
            var toG = getChart(dt, dates);
            $("canvas").mousemove((event) => handleGraph(toG, event)
            );
          });
          var toG = getChart(dt, dates);

          $("canvas").mousemove((event) => handleGraph(toG, event));
        });
        $(".form-inline").submit((ev) => {
          ev.preventDefault();
        });
        //gestione searchbar ovvero cerca articoli per ogni keyup 
        $(".form-control").keyup(() => {
          reqBodyx.pattern = ".*" + $(".form-control").val().toLowerCase();
          $.ajax({
            type: "GET",
            url: baseUrl + "articles/",
            dataType: "json",
            data: reqBodyx,
            success: (data, status, jq) => {
              $(".logo").mouseenter(() => {
                $(".logo").css("cursor", "pointer");
              });
              $(".logo").click(async () => {
                reqBodyx.isProfileSearch = false;
                await getHome(
                  $homepg,
                  baseUrl,
                  reqBodyx,
                  write_s,
                  userObj,
                  false
                );
              });
              //aggiorna home con articoli relativi a ricerca
              $("section.post").empty();
              var article = data.articles;
              for (var i = 0; i < article.length; i++) {
                var pImg = article[i].proImg;
                if (!pImg) {
                  pImg = "assets/user.png";
                }
                $("section.post").append(
                  createPost(
                    article[i].image,
                    article[i].author,
                    article[i].theme,
                    article[i].title,
                    article[i].content,
                    pImg,
                    article[i].id,
                    article[i].birth,
                    getProfile
                  )
                );
                if (reqBodyx.isProfileSearch) {
                  
                  $(".seg-del").mouseenter(function () {
                    $(this).css("cursor", "pointer");
                    $(this).css("background-color", "red");
                    $(this).css("border-radius", "4px");
                  });
                  $(".seg-del").mouseleave(function () {
                    $(this).css("cursor", "initial");
                    $(this).css("background-color", "white");
                  });
                  //cancella articolo 
                  $(".seg-del").click(function () {
                    $.ajax({
                      type: "DELETE",
                      url:
                        baseUrl +
                        "articles/" +
                        $(this).parent().parent().parent().attr("data-aid"),
                      success: async () => {
                        $(".logcss").remove();
                        await getHome(
                          $homepg,
                          baseUrl,
                          reqBodyx,
                          write_s,
                          userObj,
                          true
                        );
                      },
                    });
                  });

                  $(".seg-stat").mouseenter(function () {
                    $(this).css("cursor", "pointer");
                    $(this).css("background-color", "yellow");
                  });
                  $(".seg-stat").mouseleave(function () {
                    $(this).css("cursor", "initial");
                    $(this).css("background-color", "white");
                  });
                  // genera grafico articolo
                  $(".seg-stat").click(async function () {
                    $("section.container").remove();
                    $("label").remove();
                    $("#stat").remove();
                    $(
                      "<div id='stat' style='display:flex;justify-content: center;height:50vh;'><canvas style='align-self:center;height:100%;'></canvas></div>"
                    ).insertAfter(".post-filter");
                    $(
                      `<div id="sel-stat" style="display:flex; justify-content:center;">
                        <label for="chart-sel" style="margin-top:20px">Numero di click negli ultimi 7 giorni</label>
          
                      </div>
                    `
                    ).insertAfter(".post-filter");
                    $(".form-inline").hide();
                    $("#write-it").hide();

                    $('select[name="chart-sel"]').css({
                      color: "white",
                      "background-color": "var(--second-color)",
                      border: "none",
                      "border-radius": "2px",
                      "margin-left": "5px",
                    });

                    var ad = $(this)
                      .parent()
                      .parent()
                      .parent()
                      .attr("data-aid");
                    var dt = [];
                    var dates = genDatesStats();
                    for (var d of dates) {
                      await $.ajax({
                        type: "GET",
                        url: baseUrl + `articles/${ad}/clickStats/${d}`,
                        dataType: "json",
                        success: (data, status, jq) => {
                          dt.push(data.count);
                        },
                      });
                    }
                    $(window).on("resize", async function () {
                      $("#stat").remove();
                      $("#sel-stat").remove();
                      $(
                        "<div id='stat' style='display:flex;justify-content: center;height:50vh;'><canvas style='align-self:center;height:100%;'></canvas></div>"
                      ).insertAfter(".post-filter");
                      $(
                        `<div id="sel-stat" style="display:flex; justify-content:center;">
                        <label for="chart-sel" style="margin-top:20px">Numero di click negli ultimi 7 giorni</label>
          
                      </div>
                    `
                      ).insertAfter(".post-filter");
                      $(".form-inline").hide();
                      $("#write-it").hide();
                      var toG = getChart(dt, dates);
                      $("canvas").mousemove((event) => handleGraph(toG, event));
                    });
                    var toG = getChart(dt, dates);
                    $("canvas").mousemove((event) => handleGraph(toG, event));
                  });
                }

                $(".post-title").css("text-decoration-line", "none");
                $("a.post-title").mouseenter(() => {
                  $("a.post-title").css("cursor", "pointer");
                });
                //al click titolo articolo carica pagina post chiedendo contenuto al server 
                $("a.post-title").click((evnt) => {
                  var aid = evnt.target.dataset.aid;
                  $.get(baseUrl + "post", (data, status, jq) => {
                    var newPage = $.parseHTML($.trim(data));
                    $.get(
                      baseUrl + `articles/${aid}`,
                      (data, textStatus, jqXHR) => {
                        $("#view")
                          .append(newPage)
                          .promise()
                          .done(() => {
                            $(".logo").click(async () => {
                              reqBodyx.isProfileSearch = false;
                              await getHome(
                                $homepg,
                                baseUrl,
                                reqBodyx,
                                write_s,
                                userObj,
                                false
                              );
                              clearPg();
                            });
                            $(".logo").mouseenter(() => {
                              $(".logo").css("cursor", "pointer");
                            });

                            $(".account").click(async () => {
                              await getHome(
                                $homepg,
                                baseUrl,
                                reqBodyx,
                                write_s,
                                userObj,
                                true
                              );
                              clearPg();
                            });
                            $(".account").mouseenter(() => {
                              $(".account").css("cursor", "pointer");
                            });
                            $(".back-home").click(async () => {
                              reqBodyx.isProfileSearch = false;
                              await getHome(
                                $homepg,
                                baseUrl,
                                reqBodyx,
                                write_s,
                                userObj,
                                false
                              );
                              clearPg();
                            });
                            $(".back-home").mouseenter(() => {
                              $(".back-home").css("cursor", "pointer");
                            });
                            $(".logo").css("text-decoration-line", "none");
                            $(".account").css("text-decoration-line", "none");

                            $(".account").text(userObj.username);
                            var article = data.articles[0];
                            $(".header-title").text(
                              article.title.slice(0, 61) + "..."
                            );
                            $(".post-text").text(article.content);
                            $("#head-tit").text(article.title);
                            $(".header-img").attr("src", article.image);
                            $("#view head").remove();
                            $("#view meta").remove();
                            $("#view title").remove();
                            $("#view link").remove();
                            $(".container-cls").remove();
                            $("#bid").css("visibility", "visible");
                            document
                              .getElementById("top-jmp")
                              .scrollIntoView({ behavior: "instant" });
                            let header = document.querySelector("header");

                            window.addEventListener("scroll", () => {
                              header.classList.toggle(
                                "shadow",
                                window.scrollY > 0
                              );
                            });
                          });
                      }
                    );
                  });
                });
              }
            },
          });
        });
        $("a.post-title").mouseenter(() => {
          $("a.post-title").css("cursor", "pointer");
        });
        $(".post-title").css("text-decoration-line", "none");
        $("#write-it").click(() => {
          getWritePage($homepg, baseUrl, reqBodyx, write_s, userObj);
        });
        // carica pagina articolo al click titolo articolo
        $("a.post-title").click((evnt) => {
          var aid = evnt.target.dataset.aid;
          $.get(baseUrl + "post", (data, status, jq) => {
            var newPage = $.parseHTML($.trim(data));
            $.get(baseUrl + `articles/${aid}`, (data, textStatus, jqXHR) => {
              $("#view")
                .append(newPage)
                .promise()
                .done(() => {
                  $(".logo").click(async () => {
                    reqBodyx.isProfileSearch = false;
                    await getHome(
                      homeStyle,
                      baseUrl,
                      reqBodyx,
                      write_s,
                      userObj,
                      false
                    );
                    clearPg();
                  });
                  $(".logo").mouseenter(() => {
                    $(".logo").css("cursor", "pointer");
                  });

                  $(".account").click(async () => {
                    await getHome(
                      homeStyle,
                      baseUrl,
                      reqBodyx,
                      write_s,
                      userObj,
                      true
                    );
                    clearPg();
                  });
                  $(".account").mouseenter(() => {
                    $(".account").css("cursor", "pointer");
                  });
                  $(".back-home").click(async () => {
                    reqBodyx.isProfileSearch = false;
                    await getHome(
                      $homepg,
                      baseUrl,
                      reqBodyx,
                      write_s,
                      userObj,
                      false
                    );
                    clearPg();
                  });
                  $(".back-home").mouseenter(() => {
                    $(".back-home").css("cursor", "pointer");
                  });
                  $(".logo").css("text-decoration-line", "none");
                  $(".account").css("text-decoration-line", "none");
                  $(".account").text(userObj.username);
                  var article = data.articles[0];
                  $(".header-title").text(article.title.slice(0, 61) + "...");
                  $(".post-text").text(article.content);
                  $("#head-tit").text(article.title);
                  $(".header-img").attr("src", article.image);
                  $("#view head").remove();
                  $("#view meta").remove();
                  $("#view title").remove();
                  $("#view link").remove();
                  $(".container-cls").remove();
                  $("#bid").css("visibility", "visible");
                  document
                    .getElementById("top-jmp")
                    .scrollIntoView({ behavior: "instant" });

                  let header = document.querySelector("header");

                  window.addEventListener("scroll", () => {
                    header.classList.toggle("shadow", window.scrollY > 0);
                  });
                });
            });
          });
        });
        $(".filter-item").click(function () {
          $(this)
            .addClass("active-filter")
            .siblings()
            .removeClass("active-filter");
        });
        let header = document.querySelector("header");

        window.addEventListener("scroll", () => {
          header.classList.toggle("shadow", window.scrollY > 0);
        });
      });
    },
    error: (XMLHttpRequest, textStatus, errorThrown) => {
      alert("INTERNAL SERVER ERROR");
    },
  });
  return new Promise((resolve) => {
    resolve("");
  });
}

$(document).ready(function () {

  var baseUrl = "http://localhost:8000/";

  // mostra pagina login
  $("#view").load(baseUrl + " .hero", function (response, status) {
    var write_s = $(".wpst").detach();
    var $homepg = null;
    var lastReg = false;
    //gestione bottoni per cambio tipo form tra login e register
    $("button.toggle-btn").click(() => {
      $("#btn").css("left", "initial");
      $("#btn").css("right", "0");
      if (lastReg) {
        $("input[name='foto']").remove();
      }
      lastReg = true;
      $(`<input type="file" name="foto" required>`).insertBefore(
        "#container-error"
      );
      $("#container-error").css("display", "none");
      $("button.submit-btn").html("Register");
    });
    //gestione bottoni per cambio tipo form tra login e register
    $("#toggle-btn-").click(() => {
      lastReg = false;
      $("#btn").css("right", "initial");
      $("#btn").css("left", "0");
      $("#container-error").css("display", "inline");
      $("input[name='foto']").remove();
      $("label.filter-item").remove();
      $("button.submit-btn").html("Login");
    });
    $("input[name='pass']").after("<p id='container-error' ></p>");
    var userObj = {};
    if (status === "error") {
      alert("Failed to load resource");
    } else {
      //gestione evento submit login-register
      $("#login").submit(async function (event) {
        event.preventDefault();
        var usn = $("input[name='user']").val();
        var pass = $("input[name='pass']").val();
        var image = "";

        if (lastReg) {
          var file = $("input[name='foto']")[0].files[0];
          await getBase64(file).then((data) => {
            image = data;
          });
        }

        userObj = {
          username: usn,
          password: pass,
          img: image,
        };
        localStorage.setItem("user", JSON.stringify(userObj));
        //richiesta server auth 
        $.ajax({
          type: "POST",
          url: baseUrl + "session",
          dataType: "json",
          data: JSON.stringify(userObj),
          contentType: "application/json",
          success: async (data, status, jq) => {
            var reqBodyx = {
              pattern: ".",
              username: JSON.parse(localStorage.user).username,
              isProfileSearch: false,
            };
            $("head").append(
              `<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">`
            );
            // carica pagina home
            await getHome(
              $homepg,
              baseUrl,
              reqBodyx,
              write_s,
              userObj,
              false,
              true
            );
          },
          error: (XMLHttpRequest, textStatus, errorThrown) => {
            //errore auth
            localStorage.setItem("user", JSON.stringify({}));
            $("#container-error").html(
              "<p id='toggle-error' >Authentication Error</p>"
            );
          },
        });
      });
    }
  });
});
