// import dei moduli necessari
var express = require("express");
var app = express();
var cors = require("cors");
var path = require("path");
// debugging

//import db
var db = require("./database.js");

// set cors policy
app.use(cors());
// parsing json with high limit
app.use(express.json({ limit: "50mb" }));

// Server port
var HTTP_PORT = 8000;
// Start server
app.listen(HTTP_PORT, () => {
  console.log("Server running on port %PORT%".replace("%PORT%", HTTP_PORT));
});

// attivazione foreing keys
db.run("PRAGMA foreign_keys = ON;");

// Login endpoint
app.post("/session", (req, res) => {
  db.all("SELECT * FROM users;", (err, rows) => {

    // cerca utente
    for (var i = 0; i < rows.length; i++) {
      if (req.body.username === rows[i].username) {
        toCreate = false;
        if (req.body.password === rows[i].pass) {
          res.status(200).json(req.body);
          return;
        } else {
          res.status(401).json({});
          return;
        }
      }
    }
    // crea user
    db.run(
      "INSERT INTO users(username,pass,proImg) VALUES (?,?,?)",
      [req.body.username, req.body.password, req.body.img],
      (err, rows) => {
        if (err) {
          res.status(500).json({});
          return;
        } else {
          res.status(201).json(req.body);
          return;
        }
      }
    );
  });
});

// root doc
app.get("/", (req, res) => {
  res.status(200).sendFile(path.resolve("../src/login.html"));
});

app.get("/home", (req, res) => {
  res.status(200).sendFile(path.resolve("../src/home_page.html"));
});

app.get("/post", (req, res) => {
  res.status(200).sendFile(path.resolve("../src/post_page.html"));
});

app.get("/write", (req, res) => {
  res.status(200).sendFile(path.resolve("../src/write_post.html"));
});

// api che crea articoli e inserisce immagine
app.post("/articles/", (req, res) => {
  db.run(
    "INSERT INTO articles(title,content,theme,author,birth) VALUES (?,?,?,?,?)",
    [
      req.body.title,
      req.body.content,
      req.body.theme,
      req.body.author,
      new Date().getTime() / 1000,
    ],
    function (err, rows) {
      if (err) {
        res.status(500).json({});
        return;
      } else {
        db.run("INSERT INTO images(article,image) VALUES (?,?)", [
          this.lastID,
          req.body.image,
        ]);
        res.status(201).json({ id: this.lastID });
        return;
      }
    }
  );
});

// api che cancella articolo   height: 60vh;   max-height: 60%;

app.delete("/articles/:id", (req, res) => {
  db.run("DELETE FROM articles WHERE id=?", [req.params.id], (err, rows) => {
    if (err) {
      res.status(500).json({});
      return;
    } else {
      res.status(204).json({});
      return;
    }
  });
});

app.get("/articles/:id/clickStats/:date", (req, res) => {
  db.all("SELECT COUNT(*) AS nb FROM clickEvs WHERE aid=? AND date=?", [req.params.id,req.params.date], (err, rs) => {
    if (err) {
      res.status(500).json({});
      return;
    } else {
      res.status(200).json({ count: rs[0].nb });
      return;
    }
  });
});

app.get("/articles/:id/searchStats/:date", (req, res) => {
  db.all("SELECT COUNT(*) AS nb FROM searchEvs WHERE aid=? AND date=?", [req.params.id,req.params.date], (err, rs) => {
    if (err) {
      res.status(500).json({});
      return;
    } else {
      res.status(200).json({ count: rs[0].nb });
      return;
    }
  });
});

// ricerca articoli in base a stringa --> inserimento eventi || ricerca articoli in base all'utente

app.get("/articles/:id", (req, res) => {
  var date = new Date().toISOString().substring(6, 10);
  db.all(
    "SELECT articles.birth,articles.id,title,content,theme,author,image,proImg FROM articles INNER JOIN images ON article=articles.id  INNER JOIN users ON articles.author = users.username WHERE articles.id=? ORDER BY articles.birth DESC;",
    [req.params.id],
    (err, articles) => {
      if (err) {
        res.status(500).json({});
        return;
      } else {
        db.run(
          "INSERT INTO clickEvs(aid,date) VALUES(?,?)",
          [req.params.id, date],
          (err, res) => {}
        );
        res.status(200).json({ articles: articles });
        return;
      }
    }
  );
});
/*{
  pattern: "",
  username:"",
  isProfileSearch:false
}
*/
app.get("/articles/", (req, res) => {
  // ricerca articoli in base a utente
  var basicRegex = new RegExp(req.query.pattern + ".*");
  var artRes = [];
  if (req.query.isProfileSearch !== "false") {
    db.all(
      "SELECT articles.birth,articles.id,title,content,theme,author,image,proImg FROM articles INNER JOIN images ON article=articles.id  INNER JOIN users ON articles.author = users.username ORDER BY articles.birth DESC;",
      (err, articles) => {
        if (err) {
          res.status(500).json({});
          return;
        } else {
          for (var i = 0; i < articles.length; i++) {
            if (
              articles[i].author === req.query.username &&
              articles[i].title.toLowerCase().match(basicRegex)
            ) {
              artRes.push(articles[i]);
            }
          }
          res.status(200).json({ articles: artRes });
          return;
        }
      }
    );
  }

  // ricerca articoli in base a stringa
  else {
    db.all(
      "SELECT articles.birth,articles.id,title,content,theme,author,image,proImg FROM articles INNER JOIN images ON article=articles.id  INNER JOIN users ON articles.author = users.username ORDER BY articles.birth DESC;",
      (err, articles) => {
        if (err) {
          res.status(500).json({});
          return;
        } else {
          var date = new Date().toISOString().substring(6, 10);
          for (var i = 0; i < articles.length; i++) {
            if (articles[i].title.toLowerCase().match(basicRegex)) {
              artRes.push(articles[i]);
              db.run(
                "INSERT INTO searchEvs(aid,date) VALUES(?,?);",
                [articles[i].id, date],
                (err, dt) => {
                  if (err) {
                  } else {
                  }
                }
              );
            }
          }

          res.status(200).json({ articles: artRes });
        }
      }
    );
  }
});

//inserimento like

app.post("/articles/:id/likes/", (req, res) => {
  db.all(
    "SELECT author FROM likes WHERE article_id=?;",
    [req.params.id],
    (err, rows) => {
      if (err) {
        res.status(500).json({});
        return;
      } else {
        var toInsert = true;
        for (var i = 0; i < rows.length; i++) {
          if (rows[i].author === req.body.author) {
            toInsert = false;
          }
        }
        if (toInsert) {
          db.run(
            "INSERT INTO likes(article_id,author) VALUES(?,?)",
            [req.params.id, req.body.author],
            function (err, data) {
              if (err) {
                res.status(500).json({});
                return;
              } else {
                res.status(200).json({ id: this.lastID });
                return;
              }
            }
          );
        } else {
          res.status(200).json({});
        }
      }
    }
  );
});

//rimozione like

app.delete("/articles/:id/likes/:lid", (req, res) => {
  db.run("DELETE FROM likes WHERE id=?", [req.params.lid], (err, rows) => {
    if (err) {
      res.status(500).json({});
      return;
    } else {
      res.status(204).json({});
      return;
    }
  });
});

